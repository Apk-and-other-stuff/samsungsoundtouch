csharp-example
==============
Copyright (c) Olli Parviainen

This is a C# example application that plays MP3 audio file and 
uses SoundTouch.dll library for adjusting the sound in real-time.

The example uses NAudio library for MP3 file reading and audio playback. 
See NAudio-readme.txt and NAudio-license.txt for NAudio information.
