Building in Microsoft Windows


Project files for Microsoft Visual C++ are supplied with the source 
code package. Go to Microsoft WWW page to download 

Microsoft Visual Studio Express version for free.

(https://visualstudio.microsoft.com/vs/express/)


To build the binaries with Visual C++ compiler, either run
"make-win.bat" script, or open the appropriate project files in source
code directories with Visual Studio. The final executable will appear
under the "SoundTouch\bin" directory. If using the Visual Studio IDE
instead of the make-win.bat script, directories bin and lib may need to
be created manually to the SoundTouch package root for the final
executables. The make-win.bat script creates these directories
automatically. 


C# example: The source code package includes also a C# example application for Windows that shows how to invoke SoundTouch.dll dynamic-load library for processing mp3 audio.


OpenMP NOTE: If activating the OpenMP parallel computing in 
the compilation, the target program will require additional vcomp dll library to 
properly run. In Visual C++ 9.0 these libraries can be found in the following 
folders.


 - x86 32bit: C:\Program Files (x86)\Microsoft Visual Studio 9.0\VC\redist\x86\Microsoft.VC90.OPENMP\vcomp90.dll

 - x64 64bit: C:\Program Files (x86)\Microsoft Visual Studio 9.0\VC\redist\amd64\Microsoft.VC90.OPENMP\vcomp90.dll



In Visual Studio 2008, a SP1 version may be required for these libraries. In 
other VC++ versions the required library will be expectedly found in similar 
"redist" location.


Notice that as minor demonstration of a "dll hell" phenomenon both the 32-bit 
and 64-bit version of vcomp90.dll have the same filename but different contents, 
thus choose the proper version to allow the program start.